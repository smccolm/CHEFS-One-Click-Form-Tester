'use strict';

const VERSION = '0.2.1';
const BUILD = '2026.07.22.6';
let activeTabId = null;
let pollTimer = null;
let latestRun = null;

const elements = {
  statusPill: document.getElementById('statusPill'),
  startButton: document.getElementById('startButton'),
  stopButton: document.getElementById('stopButton'),
  exportButton: document.getElementById('exportButton'),
  copyButton: document.getElementById('copyButton'),
  settingsButton: document.getElementById('settingsButton'),
  runId: document.getElementById('runId'),
  passCount: document.getElementById('passCount'),
  filledCount: document.getElementById('filledCount'),
  remainingCount: document.getElementById('remainingCount'),
  currentAction: document.getElementById('currentAction'),
  confirmationId: document.getElementById('confirmationId'),
  message: document.getElementById('message')
};

document.getElementById('versionText').textContent = `v${VERSION} build ${BUILD}`;

function setMessage(text) {
  elements.message.textContent = text || '';
}

function renderRun(run) {
  latestRun = run || null;
  if (!run) {
    elements.statusPill.textContent = 'Ready';
    elements.statusPill.className = 'pill idle';
    elements.runId.textContent = 'None';
    elements.passCount.textContent = '0';
    elements.filledCount.textContent = '0';
    elements.remainingCount.textContent = '0';
    elements.currentAction.textContent = 'Idle';
    elements.confirmationId.textContent = '-';
    elements.startButton.classList.remove('hidden');
    elements.stopButton.classList.add('hidden');
    elements.exportButton.disabled = true;
    elements.copyButton.disabled = true;
    return;
  }

  const status = String(run.status || 'unknown').toLowerCase();
  const isRunning = ['initializing', 'scanning', 'filling', 'settling', 'validating', 'submitting', 'waiting'].includes(status);
  const isSuccess = status === 'submitted' || status === 'completed';
  const isFailure = ['failed', 'stalled', 'blocked', 'safety_stop'].includes(status);

  elements.statusPill.textContent = run.statusLabel || status.replaceAll('_', ' ');
  elements.statusPill.className = `pill ${isRunning ? 'running' : isSuccess ? 'success' : isFailure ? 'failure' : 'warning'}`;
  elements.runId.textContent = run.runId || 'Unknown';
  elements.passCount.textContent = String(run.progress && run.progress.pass || 0);
  elements.filledCount.textContent = String(run.progress && run.progress.filled || 0);
  elements.remainingCount.textContent = String(run.progress && run.progress.remaining || 0);
  elements.currentAction.textContent = run.currentAction || 'Idle';
  elements.confirmationId.textContent = run.confirmationId || '-';
  elements.startButton.classList.toggle('hidden', isRunning);
  elements.stopButton.classList.toggle('hidden', !isRunning);
  elements.exportButton.disabled = !run.runId;
  elements.copyButton.disabled = !run.runId;

  if (run.failure && run.failure.message) {
    setMessage(run.failure.message);
  } else if (run.message) {
    setMessage(run.message);
  } else {
    setMessage('');
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

async function refreshStatus() {
  if (!activeTabId) {
    return;
  }
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'GET_TAB_RUN',
      tabId: activeTabId
    });
    renderRun(response && response.run ? response.run : null);
  } catch (error) {
    setMessage(error && error.message ? error.message : 'Unable to read run status.');
  }
}

async function startRun() {
  setMessage('Starting run...');
  elements.startButton.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'START_RUN_IN_TAB',
      tabId: activeTabId
    });
    if (!response || !response.ok) {
      throw new Error(response && response.error ? response.error : 'The run could not be started.');
    }
    await refreshStatus();
  } catch (error) {
    setMessage(error && error.message ? error.message : String(error));
  } finally {
    elements.startButton.disabled = false;
  }
}

async function stopRun() {
  try {
    await chrome.tabs.sendMessage(activeTabId, { type: 'CHEFS_TESTER_STOP' });
    setMessage('Stop requested.');
  } catch (error) {
    setMessage(error && error.message ? error.message : 'Unable to stop the run.');
  }
}

async function exportRun() {
  if (!latestRun || !latestRun.runId) {
    return;
  }
  elements.exportButton.disabled = true;
  setMessage('Preparing run bundle...');
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'EXPORT_RUN',
      runId: latestRun.runId
    });
    if (!response || !response.ok) {
      throw new Error(response && response.error ? response.error : 'Export failed.');
    }
    setMessage('Run bundle download started.');
  } catch (error) {
    setMessage(error && error.message ? error.message : String(error));
  } finally {
    elements.exportButton.disabled = false;
  }
}

async function copySummary() {
  if (!latestRun || !latestRun.summaryText) {
    return;
  }
  try {
    await navigator.clipboard.writeText(latestRun.summaryText);
    setMessage('Summary copied.');
  } catch (error) {
    setMessage('Unable to copy the summary. Export the run bundle instead.');
  }
}

elements.startButton.addEventListener('click', startRun);
elements.stopButton.addEventListener('click', stopRun);
elements.exportButton.addEventListener('click', exportRun);
elements.copyButton.addEventListener('click', copySummary);
elements.settingsButton.addEventListener('click', () => chrome.runtime.openOptionsPage());

(async function initialize() {
  const tab = await getActiveTab();
  activeTabId = tab ? tab.id : null;
  if (!activeTabId) {
    setMessage('No active tab is available.');
    elements.startButton.disabled = true;
    return;
  }
  await refreshStatus();
  pollTimer = setInterval(refreshStatus, 700);
})();

window.addEventListener('unload', () => {
  if (pollTimer) {
    clearInterval(pollTimer);
  }
});
