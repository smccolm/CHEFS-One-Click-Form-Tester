# Changelog

## 0.2.1 - build 2026.07.22.6

Corrective release based on regression run `A9D2A6`.

- Prevents Form.io data-grid and edit-grid add-row controls from being indexed as submit landmarks, even when the rendered button uses `type="submit"`.
- Excludes generic add-row labels such as `Add Another`, `Add Row`, `Add Item`, and `New Row` from submit-button detection.
- Excludes lookup/search action controls from submit-button detection.
- Keeps the configured grid target at two total rows and prevents the submission stage from opening an unintended third row.
- Retains v0.2.0 custom mask rules, JSON import/export, automatic mask detection, and rule provenance.

## 0.2.0 - build 2026.07.22.5

- Detects input masks from live Form.io component metadata and runtime Inputmask configuration.
- Generates minimally conforming values for standard CHEFS `9`, `a` and `*` mask tokens while preserving literal punctuation and spaces.
- Adds a Custom field formats table to Settings with enabled state, normalized label phrase, CHEFS mask and row removal.
- Gives matching user rules precedence over detected form masks on the first attempt.
- Falls back to a conflicting form-defined mask on a later attempt when the custom value is rejected.
- Adds schema-versioned JSON Import Rules and Export Rules actions with Merge and Replace import modes.
- Validates imported JSON, rule IDs, label phrases, duplicate rules and mask syntax before changing the settings table.
- Adds the active custom rule set and rule-set SHA-256 identity to each run record and troubleshooting bundle.
- Adds `custom-format-rules.json` to run exports.
- Adds mask and custom-rule provenance to component snapshots and `FILL_ATTEMPT` events.
- Adds `CUSTOM_RULE_SET_LOADED`, `CUSTOM_RULE_MATCHED`, `CUSTOM_RULE_VALUE_ACCEPTED`, `CUSTOM_RULE_VALUE_REJECTED`, `MASK_METADATA_DETECTED`, `MASK_RUNTIME_DETECTED`, `MASK_VALUE_GENERATED`, `MASK_VALUE_PERSISTED`, `MASK_VALUE_REJECTED` and `MASK_SYNTAX_UNSUPPORTED` diagnostics.
- Retains v0.1.9 submit-landmark and hidden-tab validation behaviour.

## 0.1.9 - build 2026.07.22.4

- Records Form.io submit controls as persistent landmarks while scanning each tab.
- Remembers the tab that contains each submit control, even after that tab becomes hidden.
- Returns to the remembered submit tab when the final visited tab contains no submit control.
- Reacquires the live submit button after tab activation or Form.io redraw.
- Runs repairable Form.io validation errors before requiring a visible submit button.
- Recognizes rendered single-selection guidance such as `Please select only one` for checkbox-based choice groups.
- Prevents layout containers that inherit a child key from being treated as validation-repair fields.
- Adds submit-landmark and submit-tab diagnostic events.

## 0.1.8 - build 2026.07.22.3

Corrective release based on REDIP run `6FC991`.

- Reads checkbox-group selection limits from live Form.io validation metadata when available.
- Falls back to rendered guidance such as `Maximum 2 partners` or `You can only select up to 2 items` when schema metadata is unavailable.
- Selects only the permitted number of checkbox options and unchecks excess selections during repair.
- Preserves the fill-all behaviour for checkbox groups that do not define a maximum, while avoiding contradictory `None` or `Not applicable` choices when normal options exist.
- Corrects text-length resolution so the browser's default input `maxLength` value no longer overrides a CHEFS/Form.io validation limit.
- Reads minimum and maximum character and word limits from Form.io metadata, rendered guidance and live character counters.
- Trims generated text before dispatching it to the control.
- Collects component-level validation errors from hidden tabs and associates them with the actual CHEFS property key.
- Resets rejected fields for another fill attempt and reopens the tab containing each invalid component.
- Adds `CHECKBOX_SELECTION_LIMIT_DETECTED`, `CHECKBOX_SELECTION_REPAIRED`, `VALIDATION_REPAIR_PREPARED`, and validation-repair tab diagnostics.
- Adds resolved constraints to each `FILL_ATTEMPT` event and to component snapshots.

## 0.1.6 - build 2026.07.22.1

Corrective build based on run `3C0FD3` against **REDIP - Economic Capacity (UAT)**.

- Normalizes Form.io tab wrappers to their interactive anchor or button before clicking.
- Verifies that the requested tab became active before recording `TAB_ACTIVATED`.
- Records failed tab activation attempts and skips a tab only after two verified failures.
- Prevents false-positive tab visits caused by clicking a non-interactive `<li role="tab">` wrapper.
- Defers Next-button wizard navigation until direct traversal of the visible tab set is complete.
- Adds tab-set and activation diagnostics.
- Replaces the fixed 40-pass ceiling with a tab-aware starting budget.
- Extends the pass budget when the boundary pass made progress or revealed another conditional field.
- Retains a 200-pass hard ceiling and the existing no-progress watchdog.

## 0.1.5 - build 2026.07.21.6

Corrective build based on run `5712D1` against **Template - Custom Fields**.

- Treats the configured grid value as a target total row count rather than a number of rows to add only when the grid is empty.
- Uses a default target of two rows for every reachable data grid or edit grid.
- Counts existing rows, respects detected row limits, and adds only the missing rows.
- Finds add-row controls by Form.io class or `ref` suffix before using text as a fallback.
- Reacquires the live grid wrapper after each row addition and waits for the rendered row count to increase.
- Rescans newly created rows so every field in every row is filled.
- Adds grid diagnostics for inspection, add attempts, success, unavailable targets and target completion.
- Adds grid row count and target row count to component snapshots.
- Adds a dedicated simple-day adapter that fills month, day and year together.
- A simple-day component is no longer counted as filled when only the month has a value.
- Changes the grid setting to a target of two to five rows and migrates earlier stored values below two.

## 0.1.4 - build 2026.07.21.5

- Detects the standard CHEFS success route and success-page wording.
- Captures the confirmation ID and stops all further work after successful submission.
- Prevents broad page-level alert containers from being treated as validation errors.

## 0.1.3 - build 2026.07.21.4

- Treats count questions as counts before considering nearby funding language.
- Yields between input, change and blur events.
- Adds control-event diagnostics and an independent stale-run watchdog.

## 0.1.2 - build 2026.07.21.3

- Reacquires live Form.io file wrappers after CHEFS redraws file components.
- Detects rendered upload rows without polling detached wrappers.
- Adds stronger Choices.js interaction fallbacks.

## 0.1.1 - build 2026.07.21.2

- Corrects phone, address, distinct-email, confirmation-checkbox and file-upload handling.
- Improves wrapper-key detection and component metadata logging.

## 0.1.0 - build 2026.07.21.1

Initial complete one-button fill-and-submit implementation.
