# Troubleshooting

## A bureaucratic identifier needs a special format

Current builds inspect the live Form.io schema and runtime Inputmask configuration before generating ordinary text. Standard masks such as `aaa-999999`, `(999) 999-9999` and `*****************` are handled automatically.

When the form does not expose the necessary format, open **Settings**, add a Custom field format rule, enter a distinctive phrase from the visible field label and enter the CHEFS input mask. Label matching is case-insensitive, removes label markup and required markers, normalizes punctuation and uses phrase containment by default.

The exported run includes `custom-format-rules.json`. Component snapshots record `maskSource`, `resolvedMask`, `customRule` and `maskGenerationStrategy`. Use the mask and custom-rule events in `events.jsonl` to determine whether the value came from a user rule, Form.io metadata or runtime Inputmask settings.

If a custom rule conflicts with a detected form mask, attempt one uses the custom rule and a later attempt can use the form-defined mask. `CUSTOM_RULE_VALUE_REJECTED` records the detected fallback mask.

Optional mask groups, alternation, quantifiers and custom mask definitions are not guessed. The run records `MASK_SYNTAX_UNSUPPORTED` and continues through the normal retry and validation-repair process.

## Importing or sharing custom field format rules

Use **Export Rules** to create schema-versioned JSON. Use **Import Rules** with Merge to retain local rules or Replace to replace the current table. The importer rejects malformed JSON, unsupported schema versions, missing phrases, masks without standard tokens, duplicate IDs and duplicate phrase-and-mask rules. Imported changes are not persistent until **Save Settings** is selected.

## Submit exists on an earlier tab

v0.1.9 records every Form.io submit control as a submit landmark, including the containing tab. If the fill loop finishes on a later information-only or resources-only tab, the extension activates the remembered submit tab and reacquires the live button before submission. Relevant events are `SUBMIT_LANDMARK_DISCOVERED`, `SUBMIT_LANDMARK_BECAME_VISIBLE`, `SUBMIT_TAB_ACTIVATION_ATTEMPT`, `SUBMIT_TAB_ACTIVATED`, and `SUBMIT_LANDMARK_REACQUIRED`.

## Checkbox group says select only one

When Form.io renders a checkbox-based choice group with an error such as `Please select only one`, v0.1.9 resolves the maximum selection count as one, unchecks the excess selections, and retries validation before searching for Submit.

## A checkbox group says too many items were selected

v0.1.8 reads Form.io `minSelectedCount` and `maxSelectedCount` validation metadata. When that metadata is unavailable, it reads rendered instructions such as `Maximum 2 partners` and `You can only select up to 2 items`. The extension unchecks excess options and records `CHECKBOX_SELECTION_LIMIT_DETECTED` and `CHECKBOX_SELECTION_REPAIRED`.

## A text field contains a value but CHEFS says it is required or over length

Current builds resolve minimum and maximum character and word limits from Form.io metadata, HTML attributes, rendered guidance and live character counters. Each `FILL_ATTEMPT` event records `resolvedConstraints`. Submission repair records the component key, reopens its hidden tab when necessary, and retries it with a value inside the detected limit.

## File appears in CHEFS but the run reports an upload failure

v0.1.7 added exact wrapper tracking for Form.io file controls whose default property key is also `simplefile`. It recognizes list and table file rows and remembers in-flight uploads so a slow upload is monitored instead of repeated. Relevant events are `UPLOAD_PENDING_RECHECK`, `UPLOAD_STILL_PENDING`, `UPLOAD_PENDING_TIMEOUT`, `UPLOAD_WRAPPER_REPLACED`, and `UPLOAD_COMPLETED`.

## A run stops or stalls

Open the extension popup on the affected tab and select **Export Last Run**. Do not refresh the form first when the partial form state may be useful.

Provide the exported ZIP together with a brief visible observation. The bundle records the build, last successful action, current action, unresolved fields, validation messages, component snapshots and recent event history.

## A horizontal tabbed form stops before the final tabs are complete

v0.1.6 clicks the interactive anchor or button inside a Form.io tab wrapper and verifies that the tab became active. Logs record `TAB_SET_DISCOVERED`, `TAB_ACTIVATION_ATTEMPT`, `TAB_ACTIVATED`, `TAB_ACTIVATION_FAILED` and `TAB_SKIPPED_AFTER_FAILURE`.

The pass budget scales with the number of tabs and can extend when a boundary pass reveals another conditional field. `FILL_PASS_BUDGET_SET` and `FILL_PASS_BUDGET_EXTENDED` show the applied limits.

## A data grid receives only one row

Current builds target two total rows by default. The run log records `GRID_INSPECTED`, `GRID_ROW_ADD_ATTEMPT`, `GRID_ROW_ADDED` and `GRID_TARGET_REACHED` events. Component snapshots also record the current and target row counts.

When no enabled add-row control exists, the run records `GRID_TARGET_UNAVAILABLE` rather than repeatedly clicking the grid.

## A Day component has only a month

Current builds use a dedicated simple-day adapter. It fills month, day and year and does not count the component as filled unless every enabled part has a value.

## CHEFS submitted, but the extension reports Blocked

This was corrected in v0.1.4. Current builds detect the success route and success-page wording, capture the confirmation ID and stop the run as submitted.

## A phone field appears partly masked

Export the run bundle. The phone adapter records the input mask and requires ten rendered digits before the field is counted as filled.

## A file appears in CHEFS but the extension still says Uploading

Export the run bundle. Current builds reacquire file wrappers after Form.io redraws and inspect the replacement wrapper for the uploaded row.

## The extension says the environment is blocked

Open **Settings** and add the exact approved hostname. Production-like CHEFS hosts remain blocked unless the explicit override is enabled.
