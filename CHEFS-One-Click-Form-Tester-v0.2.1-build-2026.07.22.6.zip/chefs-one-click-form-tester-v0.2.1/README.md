# CHEFS One-Click Form Tester

Version: 0.2.1  
Build: 2026.07.22.6  
Browser: Google Chrome, Manifest V3

## Install or update

1. Extract the release ZIP to a permanent folder.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode**.
4. Remove the previous unpacked build, or select **Load unpacked** for the new folder.
5. Select the folder containing `manifest.json`.
6. Pin **CHEFS One-Click Form Tester** to the Chrome toolbar.

## Run

1. Open a fresh CHEFS form in an approved TEST, UAT or DEV environment.
2. Select the extension icon.
3. Select **Fill and Submit**.
4. Leave the form tab open while the run is active.
5. After submission, failure or a stall, select **Export Last Run**.

The engine repeatedly scans the rendered form, fills every reachable user-facing field, waits for conditional changes, creates repeating rows, uploads packaged synthetic attachments and submits after the current path stabilizes.

## v0.2.0 custom field formats

v0.2.0 reads CHEFS/Form.io input masks before using label-based value guesses. Standard CHEFS mask tokens are generated automatically: `9` for numeric, `a` for alphabetic and `*` for alphanumeric. Literal punctuation and spaces are retained.

Open **Settings** to manage **Custom field formats** when a program-area identifier needs a format that is missing from the form or needs a tester-controlled override. Each rule contains a normalized visible-label phrase and a CHEFS input mask. User rules take precedence on the first attempt; when a conflicting form-defined mask exists, the detected form mask is available as the retry fallback.

Rules can be imported and exported as schema-versioned JSON. Import supports Merge and Replace modes. The active rule set, its SHA-256 identity, every rule match and every accepted or rejected masked value are recorded in the troubleshooting bundle.

A reference file is included at `examples/custom-format-rules.example.json`.

## v0.1.9 correction

v0.1.9 treats the submit control as a persistent form landmark. When a form places Submit on an attestation tab and then adds a later resources-only tab, the extension remembers where Submit was found, returns to that tab after the fill loop, reacquires the live control, and submits. Pre-submit Form.io validation errors are repaired before submit-button discovery, including checkbox groups that render guidance such as `Please select only one`.

## v0.1.8 correction

REDIP run `6FC991` reached the final tab with 108 fields filled and five attachments completed, but submission exposed two validation defects. A checkbox group configured for a maximum of two partners had every option selected, and a 100-character conditional text field received a 282-character generated response.

v0.1.8 resolves field constraints from the live Form.io component schema before using rendered guidance. Checkbox groups obey minimum and maximum selection counts, text values obey character and word limits, and submission validation can reopen hidden tabs and retry the rejected components.

## v0.1.6 correction

Run `3C0FD3` against **REDIP - Economic Capacity (UAT)** reached 92 filled fields, four completed attachments and no validation errors, but exhausted the fixed 40-pass limit immediately after a final conditional textarea became visible. The run also exposed that the tab detector was clicking the non-interactive `<li role="tab">` wrapper rather than its child tab link, so the first 14 tab activations were logged without changing the active pane.

v0.1.6 normalizes Form.io tab wrappers to their interactive anchor or button, verifies that the requested tab became active before recording success, and only falls back to Next-button navigation after direct tab traversal has been exhausted.

The fill-pass budget is now adaptive. Forms with many tabs receive a larger starting budget, and the budget extends in small increments when the final allowed pass made progress or revealed another field. A separate hard ceiling and the existing no-progress watchdog remain in place.

## Grid settings

Open **Settings** to choose a target of two to five rows per data grid. A form-defined maximum takes precedence when it can be detected.

## Troubleshooting bundle

Every run is persisted while it executes. A partial or completed run remains exportable and can include:

- `manifest.json`
- `run-summary.txt`
- `events.jsonl`
- `checkpoints.jsonl`
- component snapshots
- validation errors
- attachment records
- the active `custom-format-rules.json` rule set and SHA-256 identity
- failure details and screenshot when applicable

## Environment protection

Automatic submission is allowed by default only on CHEFS hosts that look like TEST, UAT or DEV environments, plus localhost. Other hosts are blocked. Additional exact hostnames and an explicit production override are available under **Settings**.
