'use strict';

const EXTENSION_VERSION = '0.2.1';
const BUILD_NUMBER = '2026.07.22.6';
const RUN_KEY_PREFIX = 'chefsTesterRun:';
const TAB_KEY_PREFIX = 'chefsTesterTab:';
const LAST_RUN_KEY = 'chefsTesterLastRunId';
const SETTINGS_KEY = 'chefsTesterSettings';
const WATCHDOG_ALARM = 'chefsTesterWatchdog';
const WATCHDOG_STALE_MS = 75000;
const ACTIVE_RUN_STATUSES = new Set(['initializing', 'scanning', 'filling', 'settling', 'validating', 'submitting']);
const DEFAULT_SETTINGS = {
  additionalHosts: [],
  allowProduction: false,
  rowsPerGrid: 2,
  captureScreenshot: true,
  customFormatRules: []
};
const runLocks = new Map();

async function ensureWatchdogAlarm() {
  const existing = await chrome.alarms.get(WATCHDOG_ALARM);
  if (!existing) {
    await chrome.alarms.create(WATCHDOG_ALARM, {
      delayInMinutes: 0.5,
      periodInMinutes: 0.5
    });
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get(SETTINGS_KEY);
  const migrated = Object.assign({}, DEFAULT_SETTINGS, existing[SETTINGS_KEY] || {});
  migrated.rowsPerGrid = Math.max(2, Math.min(5, Number(migrated.rowsPerGrid) || 2));
  migrated.customFormatRules = Array.isArray(migrated.customFormatRules) ? migrated.customFormatRules : [];
  await chrome.storage.local.set({ [SETTINGS_KEY]: migrated });
  await ensureWatchdogAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  ensureWatchdogAlarm().catch(() => undefined);
});

ensureWatchdogAlarm().catch(() => undefined);

function runKey(runId) {
  return `${RUN_KEY_PREFIX}${runId}`;
}

function tabKey(tabId) {
  return `${TAB_KEY_PREFIX}${tabId}`;
}

async function getSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return Object.assign({}, DEFAULT_SETTINGS, stored[SETTINGS_KEY] || {});
}

function isDefaultAllowedHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host === 'localhost' ||
    host === '127.0.0.1' ||
    /^chefs-(test|uat|dev|development|qa)\./.test(host) ||
    /\.(test|uat|dev)\.[a-z0-9.-]+$/.test(host);
}

function isProductionLikeHost(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host.includes('chefs') && !isDefaultAllowedHost(host);
}

async function evaluateEnvironment(urlText) {
  let url;
  try {
    url = new URL(urlText);
  } catch (error) {
    return { allowed: false, reason: 'The active tab does not have a valid web address.' };
  }
  if (!['http:', 'https:'].includes(url.protocol)) {
    return { allowed: false, reason: 'Open a CHEFS form in a normal web tab first.' };
  }
  const settings = await getSettings();
  const host = url.hostname.toLowerCase();
  const additional = (settings.additionalHosts || []).map((value) => String(value).toLowerCase());
  if (isDefaultAllowedHost(host) || additional.includes(host)) {
    return { allowed: true, environment: 'non-production', settings };
  }
  if (settings.allowProduction && isProductionLikeHost(host)) {
    return { allowed: true, environment: 'production-override', settings };
  }
  return {
    allowed: false,
    reason: `Automatic submission is blocked on ${host}. Add the hostname in extension settings only when that environment is approved.`,
    settings
  };
}

async function readRun(runId) {
  if (!runId) {
    return null;
  }
  const stored = await chrome.storage.local.get(runKey(runId));
  return stored[runKey(runId)] || null;
}

function withRunLock(runId, operation) {
  const previous = runLocks.get(runId) || Promise.resolve();
  const next = previous
    .catch(() => undefined)
    .then(operation);
  const tracked = next.finally(() => {
    if (runLocks.get(runId) === tracked) {
      runLocks.delete(runId);
    }
  });
  runLocks.set(runId, tracked);
  return tracked;
}

async function mutateRun(runId, mutator) {
  return withRunLock(runId, async () => {
    const run = await readRun(runId);
    if (!run) {
      throw new Error(`Run ${runId} was not found.`);
    }
    const result = await mutator(run);
    run.updatedAt = new Date().toISOString();
    await chrome.storage.local.set({ [runKey(runId)]: run });
    return result === undefined ? run : result;
  });
}

function buildSummaryText(run) {
  const progress = run.progress || {};
  const failure = run.failure || {};
  const lines = [
    'CHEFS One-Click Form Tester',
    '',
    `Version: ${run.extensionVersion || EXTENSION_VERSION}`,
    `Build: ${run.buildNumber || BUILD_NUMBER}`,
    `Run ID: ${run.runId || 'Unknown'}`,
    '',
    `Form: ${run.formTitle || 'Unknown'}`,
    `URL: ${run.formUrl || 'Unknown'}`,
    `Result: ${String(run.status || 'UNKNOWN').toUpperCase()}`,
    '',
    `Passes completed: ${progress.pass || 0}`,
    `Components discovered: ${progress.discovered || 0}`,
    `Fields filled: ${progress.filled || 0}`,
    `Visible empty fields remaining: ${progress.remaining || 0}`,
    `Fields failed: ${progress.failed || 0}`,
    `Fields unsupported: ${progress.unsupported || 0}`,
    `Rows added: ${progress.rowsAdded || 0}`,
    `Attachments completed: ${progress.attachmentsCompleted || 0}`,
    `Attachments pending: ${progress.attachmentsPending || 0}`,
    `Submission attempts: ${progress.submitAttempts || 0}`,
    '',
    `Custom format rules loaded: ${progress.customRulesLoaded || (run.customRuleSet && run.customRuleSet.enabledRuleCount) || 0}`,
    `Custom rules matched: ${progress.customRuleMatches || 0}`,
    `Custom rule values accepted: ${progress.customRuleAccepted || 0}`,
    `Custom rule values rejected: ${progress.customRuleRejected || 0}`,
    `Detected masks used: ${progress.detectedMasksUsed || 0}`,
    `Mask values rejected: ${progress.maskValuesRejected || 0}`,
    `Rule-set hash: ${(run.customRuleSet && run.customRuleSet.ruleSetHash) || 'None'}`,
    '',
    'Last successful action:',
    run.lastSuccessfulAction || 'None recorded',
    '',
    'Current action:',
    run.currentAction || 'None recorded'
  ];
  if (run.confirmationId) {
    lines.push('', `Confirmation ID: ${run.confirmationId}`);
  }
  if (failure.message || failure.reason) {
    lines.push('', 'Failure or stall:', failure.message || failure.reason);
  }
  if (run.message) {
    lines.push('', 'Run message:', run.message);
  }
  return lines.join('\n');
}

function publicRun(run) {
  if (!run) {
    return null;
  }
  return {
    runId: run.runId,
    extensionVersion: run.extensionVersion,
    buildNumber: run.buildNumber,
    status: run.status,
    statusLabel: run.statusLabel,
    formTitle: run.formTitle,
    formUrl: run.formUrl,
    progress: run.progress || {},
    currentAction: run.currentAction,
    lastSuccessfulAction: run.lastSuccessfulAction,
    confirmationId: run.confirmationId,
    message: run.message,
    failure: run.failure ? {
      message: run.failure.message,
      reason: run.failure.reason,
      fieldKey: run.failure.fieldKey
    } : null,
    updatedAt: run.updatedAt,
    summaryText: buildSummaryText(run)
  };
}

async function createRun(message, sender) {
  const tabId = message.tabId || (sender.tab && sender.tab.id);
  const run = {
    runId: message.runId,
    tabId,
    extensionVersion: EXTENSION_VERSION,
    buildNumber: BUILD_NUMBER,
    engineVersion: EXTENSION_VERSION,
    chromeVersion: message.chromeVersion || '',
    formTitle: message.formTitle || '',
    formUrl: message.formUrl || '',
    formId: message.formId || '',
    startedAt: message.startedAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    endedAt: null,
    status: 'initializing',
    statusLabel: 'Initializing',
    message: '',
    currentAction: 'Starting run',
    lastSuccessfulAction: '',
    confirmationId: null,
    customRuleSet: message.customRuleSet || { schemaVersion: 1, enabledRuleCount: 0, ruleSetHash: '', lastModifiedAt: '' },
    customFormatRules: Array.isArray(message.customFormatRules) ? message.customFormatRules : [],
    progress: {
      pass: 0,
      discovered: 0,
      filled: 0,
      remaining: 0,
      failed: 0,
      unsupported: 0,
      rowsAdded: 0,
      attachmentsCompleted: 0,
      attachmentsPending: 0,
      submitAttempts: 0,
      customRulesLoaded: message.customRuleSet && message.customRuleSet.enabledRuleCount || 0,
      customRuleMatches: 0,
      customRuleAccepted: 0,
      customRuleRejected: 0,
      detectedMasksUsed: 0,
      maskValuesRejected: 0
    },
    events: [],
    checkpoints: [],
    snapshots: {},
    validationErrors: [],
    attachments: [],
    failure: null,
    failureScreenshotDataUrl: null
  };
  await chrome.storage.local.set({
    [runKey(run.runId)]: run,
    [tabKey(tabId)]: run.runId,
    [LAST_RUN_KEY]: run.runId
  });
  return publicRun(run);
}

async function appendEvent(message) {
  return mutateRun(message.runId, (run) => {
    const events = Array.isArray(message.events) ? message.events : [message.event];
    for (const event of events.filter(Boolean)) {
      run.events.push(event);
    }
    if (run.events.length > 12000) {
      run.events = run.events.slice(-12000);
      run.message = 'The oldest events were removed because the run exceeded the event retention limit.';
    }
  });
}

async function addCheckpoint(message) {
  return mutateRun(message.runId, (run) => {
    run.checkpoints.push(message.checkpoint);
    if (run.checkpoints.length > 3000) {
      run.checkpoints = run.checkpoints.slice(-3000);
    }
  });
}

async function updateRun(message) {
  return mutateRun(message.runId, (run) => {
    const patch = message.patch || {};
    if (patch.progress) {
      run.progress = Object.assign({}, run.progress || {}, patch.progress);
      delete patch.progress;
    }
    Object.assign(run, patch);
    if (['submitted', 'failed', 'stalled', 'blocked', 'stopped', 'safety_stop', 'completed'].includes(run.status)) {
      run.endedAt = run.endedAt || new Date().toISOString();
    }
  });
}

async function setSnapshot(message) {
  return mutateRun(message.runId, (run) => {
    run.snapshots[message.name] = message.snapshot;
  });
}

async function addValidationErrors(message) {
  return mutateRun(message.runId, (run) => {
    const errors = Array.isArray(message.errors) ? message.errors : [];
    run.validationErrors.push(...errors);
  });
}

async function addAttachmentRecord(message) {
  return mutateRun(message.runId, (run) => {
    run.attachments.push(message.attachment);
  });
}

async function setFailure(message, sender) {
  const run = await mutateRun(message.runId, (storedRun) => {
    storedRun.failure = message.failure || { message: 'Unknown failure' };
    storedRun.status = message.status || storedRun.status || 'failed';
    storedRun.statusLabel = message.statusLabel || String(storedRun.status).replaceAll('_', ' ');
    storedRun.endedAt = storedRun.endedAt || new Date().toISOString();
  });
  const settings = await getSettings();
  const tabId = (sender.tab && sender.tab.id) || run.tabId;
  if (settings.captureScreenshot && tabId) {
    try {
      const tab = await chrome.tabs.get(tabId);
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      await mutateRun(message.runId, (storedRun) => {
        storedRun.failureScreenshotDataUrl = dataUrl;
      });
    } catch (error) {
      await appendEvent({
        runId: message.runId,
        event: {
          time: new Date().toISOString(),
          event: 'SCREENSHOT_CAPTURE_FAILED',
          message: error && error.message ? error.message : String(error)
        }
      });
    }
  }
  return true;
}

async function detectStaleRuns() {
  const stored = await chrome.storage.local.get(null);
  const now = Date.now();
  const candidates = Object.entries(stored)
    .filter(([key, value]) => key.startsWith(RUN_KEY_PREFIX) && value && ACTIVE_RUN_STATUSES.has(value.status));

  for (const [, candidate] of candidates) {
    const updated = Date.parse(candidate.updatedAt || candidate.startedAt || '');
    if (!Number.isFinite(updated) || now - updated < WATCHDOG_STALE_MS) {
      continue;
    }
    const staleForMs = now - updated;
    await appendEvent({
      runId: candidate.runId,
      event: {
        time: new Date().toISOString(),
        event: 'WATCHDOG_STALL_DETECTED',
        pass: candidate.progress && candidate.progress.pass || 0,
        staleForMs,
        currentAction: candidate.currentAction || '',
        lastSuccessfulAction: candidate.lastSuccessfulAction || '',
        message: 'No diagnostic heartbeat was persisted within the watchdog window.'
      }
    });
    await setFailure({
      runId: candidate.runId,
      status: 'stalled',
      statusLabel: 'Stalled',
      failure: {
        time: new Date().toISOString(),
        reason: 'Background watchdog detected no diagnostic heartbeat.',
        message: `The run stopped persisting progress for ${Math.round(staleForMs / 1000)} seconds.`,
        currentAction: candidate.currentAction || '',
        lastSuccessfulAction: candidate.lastSuccessfulAction || '',
        watchdog: true,
        staleForMs
      }
    }, { tab: { id: candidate.tabId } });
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === WATCHDOG_ALARM) {
    detectStaleRuns().catch(() => undefined);
  }
});

async function getTabRun(tabId) {
  const stored = await chrome.storage.local.get([tabKey(tabId), LAST_RUN_KEY]);
  const runId = stored[tabKey(tabId)] || stored[LAST_RUN_KEY];
  return publicRun(await readRun(runId));
}

async function startRunInTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const environment = await evaluateEnvironment(tab.url || '');
  if (!environment.allowed) {
    throw new Error(environment.reason);
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    files: ['page-bridge.js']
  });
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['content-script.js']
  });
  const response = await chrome.tabs.sendMessage(tabId, {
    type: 'CHEFS_TESTER_START',
    settings: environment.settings,
    environment: environment.environment,
    extensionVersion: EXTENSION_VERSION,
    buildNumber: BUILD_NUMBER
  });
  return response || { ok: true };
}

function encodeUtf8(text) {
  return new TextEncoder().encode(String(text));
}

function uint16(value) {
  return new Uint8Array([value & 0xff, (value >>> 8) & 0xff]);
}

function uint32(value) {
  return new Uint8Array([
    value & 0xff,
    (value >>> 8) & 0xff,
    (value >>> 16) & 0xff,
    (value >>> 24) & 0xff
  ]);
}

function concatArrays(arrays) {
  const length = arrays.reduce((sum, array) => sum + array.length, 0);
  const output = new Uint8Array(length);
  let offset = 0;
  for (const array of arrays) {
    output.set(array, offset);
    offset += array.length;
  }
  return output;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function dosDateTime(date) {
  const year = Math.max(1980, date.getFullYear());
  const dosTime = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const dosDate = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { dosTime, dosDate };
}

function createZip(files) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  const now = dosDateTime(new Date());

  for (const file of files) {
    const nameBytes = encodeUtf8(file.name);
    const data = file.data instanceof Uint8Array ? file.data : encodeUtf8(file.data);
    const crc = crc32(data);
    const localHeader = concatArrays([
      uint32(0x04034b50),
      uint16(20),
      uint16(0x0800),
      uint16(0),
      uint16(now.dosTime),
      uint16(now.dosDate),
      uint32(crc),
      uint32(data.length),
      uint32(data.length),
      uint16(nameBytes.length),
      uint16(0),
      nameBytes
    ]);
    localParts.push(localHeader, data);

    const centralHeader = concatArrays([
      uint32(0x02014b50),
      uint16(20),
      uint16(20),
      uint16(0x0800),
      uint16(0),
      uint16(now.dosTime),
      uint16(now.dosDate),
      uint32(crc),
      uint32(data.length),
      uint32(data.length),
      uint16(nameBytes.length),
      uint16(0),
      uint16(0),
      uint16(0),
      uint16(0),
      uint32(0),
      uint32(offset),
      nameBytes
    ]);
    centralParts.push(centralHeader);
    offset += localHeader.length + data.length;
  }

  const local = concatArrays(localParts);
  const central = concatArrays(centralParts);
  const end = concatArrays([
    uint32(0x06054b50),
    uint16(0),
    uint16(0),
    uint16(files.length),
    uint16(files.length),
    uint32(central.length),
    uint32(local.length),
    uint16(0)
  ]);
  return concatArrays([local, central, end]);
}

function dataUrlToBytes(dataUrl) {
  const comma = dataUrl.indexOf(',');
  const base64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function bytesToBase64(bytes) {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function prettyJson(value) {
  return JSON.stringify(value, null, 2);
}

async function exportRun(runId) {
  const run = await readRun(runId);
  if (!run) {
    throw new Error(`Run ${runId} was not found.`);
  }
  const files = [
    {
      name: 'manifest.json',
      data: prettyJson({
        extensionVersion: run.extensionVersion,
        buildNumber: run.buildNumber,
        engineVersion: run.engineVersion,
        chromeVersion: run.chromeVersion,
        runId: run.runId,
        tabId: run.tabId,
        formTitle: run.formTitle,
        formUrl: run.formUrl,
        formId: run.formId,
        startedAt: run.startedAt,
        endedAt: run.endedAt,
        result: run.status,
        customRuleSet: run.customRuleSet || null
      })
    },
    { name: 'run-summary.txt', data: buildSummaryText(run) },
    { name: 'events.jsonl', data: (run.events || []).map((event) => JSON.stringify(event)).join('\n') },
    { name: 'checkpoints.jsonl', data: (run.checkpoints || []).map((checkpoint) => JSON.stringify(checkpoint)).join('\n') },
    { name: 'initial-components.json', data: prettyJson(run.snapshots && run.snapshots.initial || []) },
    { name: 'last-known-components.json', data: prettyJson(run.snapshots && run.snapshots.lastKnown || []) },
    { name: 'final-components.json', data: prettyJson(run.snapshots && run.snapshots.final || []) },
    { name: 'validation-errors.json', data: prettyJson(run.validationErrors || []) },
    { name: 'attachments.json', data: prettyJson(run.attachments || []) },
    {
      name: 'custom-format-rules.json',
      data: prettyJson({
        schemaVersion: run.customRuleSet && run.customRuleSet.schemaVersion || 1,
        ruleSetHash: run.customRuleSet && run.customRuleSet.ruleSetHash || '',
        enabledRuleCount: run.customRuleSet && run.customRuleSet.enabledRuleCount || 0,
        rules: run.customFormatRules || []
      })
    }
  ];
  if (run.failure) {
    files.push({ name: 'failure.json', data: prettyJson(run.failure) });
  }
  if (run.failureScreenshotDataUrl) {
    files.push({ name: 'failure-screenshot.png', data: dataUrlToBytes(run.failureScreenshotDataUrl) });
  }
  const zip = createZip(files);
  const safeRun = String(run.runId).replace(/[^A-Za-z0-9_-]/g, '');
  const stamp = new Date(run.startedAt || Date.now()).toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
  const filename = `chefs-one-click-tester-v${run.extensionVersion}-build-${run.buildNumber}-run-${safeRun}-${stamp}.zip`;
  const url = `data:application/zip;base64,${bytesToBase64(zip)}`;
  await chrome.downloads.download({ url, filename, saveAs: true });
  return filename;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case 'START_RUN_IN_TAB':
        return await startRunInTab(message.tabId);
      case 'CREATE_RUN':
        return { ok: true, run: await createRun(message, sender) };
      case 'APPEND_EVENTS':
        await appendEvent(message);
        return { ok: true };
      case 'ADD_CHECKPOINT':
        await addCheckpoint(message);
        return { ok: true };
      case 'UPDATE_RUN':
        await updateRun(message);
        return { ok: true };
      case 'SET_SNAPSHOT':
        await setSnapshot(message);
        return { ok: true };
      case 'ADD_VALIDATION_ERRORS':
        await addValidationErrors(message);
        return { ok: true };
      case 'ADD_ATTACHMENT_RECORD':
        await addAttachmentRecord(message);
        return { ok: true };
      case 'SET_FAILURE':
        await setFailure(message, sender);
        return { ok: true };
      case 'GET_TAB_RUN':
        return { ok: true, run: await getTabRun(message.tabId) };
      case 'EXPORT_RUN':
        return { ok: true, filename: await exportRun(message.runId) };
      case 'GET_SETTINGS':
        return { ok: true, settings: await getSettings() };
      default:
        return { ok: false, error: `Unknown message type: ${message.type}` };
    }
  })()
    .then(sendResponse)
    .catch((error) => sendResponse({
      ok: false,
      error: error && error.message ? error.message : String(error)
    }));
  return true;
});
